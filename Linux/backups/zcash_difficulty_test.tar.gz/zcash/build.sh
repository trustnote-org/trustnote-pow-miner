g++ -g -o test -std=c++11 -I. -I./comat -I./crypto test.cpp  utilstrencodings.cpp arith_uint256.cpp uint256.cpp
