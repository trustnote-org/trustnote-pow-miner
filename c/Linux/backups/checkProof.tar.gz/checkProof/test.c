//compile with
//gcc -o quickbench quickbench.c equihash_avx2.o
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#include "proof.h"


int main(void)
{
	int res = checkProofOfWork("06ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff",
				   537395199,
			 	   "07ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff");
	printf("res: %d\n", res);
	return 0;
}
