//compile with
//gcc -o quickbench quickbench.c equihash_avx2.o
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>

#define CONTEXT_SIZE 178033152
#define ITERATIONS 10

//Linkage with assembly
//EhPrepare takes in 136 bytes of input. The remaining 4 bytes of input is fed as nonce to EhSolver.
//EhPrepare saves the 136 bytes in context, and EhSolver can be called repeatedly with different nonce.
void EhPrepare(void *context, void *input);
int32_t EhSolver(void *context, uint32_t nonce);
extern char testinput[];

void ByteToHexStr(const uint8_t* source, char* dest, int sourceLen)
{
    short i;
    unsigned char highByte, lowByte;
 
    for (i = 0; i < sourceLen; i++)
    {
        highByte = source[i] >> 4;
        lowByte = source[i] & 0x0f ;

        if (highByte > 0x09)
                dest[i * 2] = highByte + 0x57;
        else
                dest[i * 2] = highByte | 0x30;
 
        if (lowByte > 0x09)
            dest[i * 2 + 1] = lowByte + 0x57;
        else
            dest[i * 2 + 1] = lowByte | 0x30;
    }
    return;
}

int fulltest(uint8_t* context, char* target, int conLen){

	unsigned char highByte, lowByte;
	char buff[2];

	for(int i = 0;i < conLen; i++){

		highByte = context[i] >> 4;
		lowByte = context[i] & 0x0f;

		if (highByte > 0x09)
                buff[0] = highByte + 0x57;
        else
                buff[0] = highByte | 0x30;
		if(buff[0] != target[i*2])
			return -1;
		
        if (lowByte > 0x09)
            buff[1] = lowByte + 0x57;
        else
            buff[1] = lowByte | 0x30;
		if(buff[1] != target[i*2+1])
			return -1;

	}

	return 0;
}

int equihash(uint8_t* input, uint32_t nonce, char* target, int inputlen){

	void *context_alloc, *context;
	char *pTarget = target;
	uint8_t outctx[32];
	char buff[64];
	int err = -1;

	context_alloc = malloc(CONTEXT_SIZE+4096);
	context = (void*) (((long) context_alloc+4095) & -4096);

	if(inputlen != 140)
		goto OUT;

	if(!strncasecmp("0x", target, 2)){
		pTarget = &target[2];
	}

	EhPrepare(context, input);
	int32_t numsolutions = EhSolver(context, nonce);
	printf("numsolutions = %d\n", numsolutions);
	for(int i = 0; i < numsolutions; i++){
		blake2b((uint8_t*)outctx, (uint8_t*)context+i*1344, NULL, sizeof(outctx), 1344, 0);
		if(!fulltest(outctx, pTarget, 32)){
			ByteToHexStr(outctx, buff, 32);
			printf("target = %.*s\n\n", 64, buff);
			err = 0; break;
		}
	}

OUT:
	free(context_alloc);

	return err;
}

int main(void)
{
	void *context_alloc, *context, *context_end;
	uint32_t *pu32;
	uint64_t *pu64, previous_rdtsc;
	uint8_t inputheader[140];	//140 byte header
	FILE *infile, *outfile;
	struct timespec time0, time1;
	long t0, t1;
	int32_t numsolutions, total_solutions;
	uint32_t nonce, delta_time, total_time;
	int i, j;

	context_alloc = malloc(CONTEXT_SIZE+4096);
	context = (void*) (((long) context_alloc+4095) & -4096);
	context_end = context + CONTEXT_SIZE;

	infile = 0;
	infile = fopen("input.bin", "rb");
	if (infile) {
		puts("Reading input.bin");
		fread(inputheader, 140, 1, infile);
		fclose(infile);
	} else {
		puts("input.bin not found, use sample data (beta1 testnet block 2)");
		memcpy(inputheader, testinput, 140);
	}
	
	int res = equihash(inputheader,
		85,
		"3270bcfd5d77014d85208e39d8608154c89ea10b51a1ba668bc87193340cdd67",
		sizeof(inputheader));
	

	char buff[280];
	ByteToHexStr(inputheader, buff, 140);
	printf("input: %.*s\n", 280, buff);

	
	nonce = 85;	
	EhPrepare(context, (void *) inputheader);
	uint8_t outctx[32];

	for (i=0; i<ITERATIONS; i++) {
		numsolutions = EhSolver(context, nonce);
		for(int i = 0; i < numsolutions; i++){
			blake2b((uint8_t*)outctx, (uint8_t*)context+i*1344, NULL, sizeof(outctx), 1344, 0);
			ByteToHexStr(outctx, buff, 32);
			printf("nonce: %d\t buff: %.*s\n", nonce, 64, buff);
		}
		nonce++;
	}

	free(context_alloc);
	return 0;
}
